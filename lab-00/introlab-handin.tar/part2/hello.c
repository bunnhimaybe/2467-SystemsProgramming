#include <stdio.h>
#define RETURNVALUE 67

int main()
{
    int retval = RETURNVALUE;

    printf("Hello world.\n");

    return retval;
}
